var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvw~",
  1: "cflrw",
  2: "w",
  3: "cfmtw",
  4: "_abcdefghiklorstw~",
  5: "cfgnors",
  6: "cfinorstv",
  7: "_abcdefhlmnoprstuw",
  8: "flw",
  9: "w"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Pages"
};

